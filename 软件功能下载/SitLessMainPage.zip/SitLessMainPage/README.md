这是我的大三上的前端大作业 😊

```
坐不住官方主页
├─ about.html
├─ css
│  ├─ about.css
│  ├─ footer.css
│  ├─ funs.css
│  ├─ general.css
│  ├─ indexx.css
│  ├─ nav.css
│  └─ star_canvas.css
├─ footer.html
├─ fun0.html
├─ fun1.html
├─ fun2.html
├─ funs.html
├─ images
│  ├─ img1.png
│  ├─ img10.png
│  ├─ img11.png
│  ├─ img2.png
│  ├─ img3.png
│  ├─ img4.png
│  ├─ img5.png
│  ├─ img6.png
│  ├─ img7.png
│  ├─ img9.png
│  ├─ moon.png
│  └─ star.png
├─ index.html
├─ js
│  ├─ footer.js
│  ├─ funs.js
│  ├─ fun_common.js
│  ├─ index.js
│  ├─ jquery.js
│  └─ star_canvas.js
├─ nav.html
└─ README.md

```